window.onload = () =>{
    xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://pokeapi.co/api/v2/pokemon?limit=8', true);

    xhr.onreadystatechange = () =>{
        if (xhr.readyState === 4 && xhr.status === 200){
            let response = xhr.responseText
            let responseJSON = JSON.parse(response);
            console.log(responseJSON.results);
            mainContainer = document.querySelector(".container");

            let gridParent = document.createElement("div");
            gridParent.classList.add('grid');
            mainContainer.appendChild(gridParent);
            contador = 0;

            responseJSON.results.forEach(pokemon => {
                contador++;
                let xhrPokemon = new XMLHttpRequest();
                xhrPokemon.open('GET', `https://pokeapi.co/api/v2/pokemon/${pokemon['name']}`, true);

                xhrPokemon.onreadystatechange = () =>{
                    if (xhrPokemon.readyState === 4 && xhrPokemon.status === 200){
                        let response = xhrPokemon.responseText
                        let responsePokemonJSON = JSON.parse(response);
                        
                        mainContainer = document.querySelector(".container");

                        if (responsePokemonJSON.id === contador){
                            let card = document.createElement('div');
                            card.classList.add("card");
                            
                            let containerImage = document.createElement('div');
                            containerImage.classList.add('containerImg')
                            let image = document.createElement('img');
                            image.classList.add('cardImg');
                            image.setAttribute('src', responsePokemonJSON.sprites.other.dream_world.front_default)
                            containerImage.appendChild(image);
                            card.appendChild(containerImage);
    
                            
                            let nameContainer = document.createElement('div');
                            nameContainer.classList.add('containerName')
    
                            let pokemonName = document.createElement('h5');
                            pokemonName.classList.add('cardTitle');
                            pokemonName.innerText = pokemon['name'];
    
                            let idPokemon = document.createElement('span');
                            idPokemon.innerText = '#' + responsePokemonJSON.id.toString().padStart(4, '0');
                            
                            nameContainer.appendChild(pokemonName);
                            nameContainer.appendChild(idPokemon);
                            
                            card.appendChild(nameContainer);        
                            gridParent.appendChild(card)

                        }


                        
                    }
                }
                xhrPokemon.send();
            });


        }
    }
    xhr.send();
}